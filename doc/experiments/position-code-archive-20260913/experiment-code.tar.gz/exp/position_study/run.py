"""One mode per GPU, both tasks in sequence; freeze source before running."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from exp.position_study.common import MODES, atomic_json


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    p=argparse.ArgumentParser(); p.add_argument("--root",type=Path,required=True)
    p.add_argument("--source",type=Path,required=True); args=p.parse_args()
    root=args.root.resolve(); source=args.source.resolve()
    (root/"logs").mkdir(exist_ok=True,parents=True)
    (root/"runs").mkdir(exist_ok=True)
    commit=subprocess.check_output(["git","rev-parse","HEAD"],cwd=source,text=True).strip()
    if subprocess.check_output(["git","status","--porcelain"],cwd=source,text=True):
        raise RuntimeError("source must be clean")
    if any((root/f"{mode}-{task}.json").exists() for mode in MODES for task in ("copying","selective-copying")):
        raise FileExistsError("manifests already exist; refusing to restart")

    def worker(pair):
        gpu,mode=pair
        for task in ("copying","selective-copying"):
            name=f"{mode}-{task}"; run_dir=root/"runs"/name
            path=root/f"{name}.json"
            manifest=dict(mode=mode,task=task,gpu=gpu,source=str(source),commit=commit,
                          run_dir=str(run_dir),state="queued",commands=[],started=now())
            atomic_json(path,manifest)
            commands=[("train",[sys.executable,"exp/position_study/train.py","--mode",mode,
                                "--task",task,"--run-dir",str(run_dir)])]
            for checkpoint in ("best","final"):
                commands.append((f"eval-{checkpoint}",[sys.executable,"exp/position_study/evaluate.py",
                                 "--task",task,"--run-dir",str(run_dir),"--checkpoint",checkpoint]))
            for state,command in commands:
                manifest["state"]=state
                entry=dict(command=command,started=now(),returncode=None)
                manifest["commands"].append(entry); atomic_json(path,manifest)
                try:
                    with (root/"logs"/f"{name}-{state}.log").open("w") as log:
                        result=subprocess.run(command,cwd=source,stdout=log,stderr=subprocess.STDOUT,
                                              env={**os.environ,"CUDA_VISIBLE_DEVICES":str(gpu),
                                                   "OMP_NUM_THREADS":"1","MKL_NUM_THREADS":"1"})
                    entry.update(returncode=result.returncode,finished=now())
                    if result.returncode:
                        raise RuntimeError(f"{name} {state} exited {result.returncode}")
                except Exception as exc:
                    manifest.update(state="failed",error=str(exc)); atomic_json(path,manifest)
                    raise
                atomic_json(path,manifest)
            manifest.update(state="complete",finished=now()); atomic_json(path,manifest)
            print(name,"complete",flush=True)

    with ThreadPoolExecutor(6) as pool:
        list(pool.map(worker,enumerate(MODES)))


if __name__=="__main__": main()
