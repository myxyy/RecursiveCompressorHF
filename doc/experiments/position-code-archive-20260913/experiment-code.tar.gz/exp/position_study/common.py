"""Shared study configuration and streaming evaluation; no task-specific model cues."""
import hashlib
import json
from pathlib import Path
import sys

import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from configuration_logkv import LogKVConfig
from logkv_lm import LogKVLM
from exp.position_study.task import make_batch, score

MODES = ("none", "phase2", "binding", "relative-kv", "combined", "combined-no-decay")
MEMORIES = (10, 16, 32, 64)


def model_config(mode):
    if mode not in MODES:
        raise ValueError(mode)
    return LogKVConfig(vocab_size=10, d_model=512, num_heads=8, d_ff=1024,
                       num_layers=2, chunk_size=4, gated_attention=True, self_slot=True,
                       phase_emb=mode == "phase2", phase_levels=2,
                       compressor_position_transform=mode in ("binding", "combined", "combined-no-decay"),
                       relative_position_kv=mode in ("relative-kv", "combined", "combined-no-decay"),
                       level_decay_scale=0.0 if mode == "combined-no-decay" else 1.0,
                       pad_token_id=None, bos_token_id=None, eos_token_id=None)


def initialize(mode, seed):
    # Explicitly match ALL common weights, including the phase2 control.
    torch.manual_seed(seed)
    baseline = LogKVLM(model_config("none"))
    common = baseline.state_dict()
    torch.manual_seed(seed)
    model = LogKVLM(model_config(mode))
    missing, unexpected = model.load_state_dict(common, strict=False)
    assert not unexpected
    assert all(any(k in name for k in ("phase_emb", "position_vectors", "position_permutations", "relative_key", "relative_value"))
               for name in missing)
    digest = hashlib.sha256()
    for name, tensor in sorted(common.items()):
        assert torch.equal(model.state_dict()[name], tensor)
        digest.update(name.encode()); digest.update(tensor.numpy().tobytes())
    torch.manual_seed(seed)
    return model, digest.hexdigest()


def cell_seed(task, memory, horizon, prefix, seed):
    text = f"{task}:{memory}:{horizon}:{prefix}:{seed}"
    return int.from_bytes(hashlib.sha256(text.encode()).digest()[:8], "little") % (2**63 - 1)


@torch.no_grad()
def evaluate_cell(model, task, memory, horizon, prefix, samples, seed, device,
                  chunk_size=4096, precision="autocast", batch_limit=64):
    length = prefix + horizon + 2 * memory
    batch = min(batch_limit, max(1, 2**18 // length))
    gen = torch.Generator().manual_seed(cell_seed(task, memory, horizon, prefix, seed))
    totals = [0, 0, 0, 0]
    for start in range(0, samples, batch):
        inputs, labels = make_batch(task, memory, horizon, prefix, min(batch, samples-start), gen, device)
        hidden = None
        answer = []
        answer_start = length - memory
        with torch.autocast(device_type=device.type, dtype=torch.bfloat16,
                            enabled=device.type == "cuda" and precision == "autocast"):
            for offset in range(0, length, chunk_size):
                logits, hidden = model.step(inputs[:, offset:offset+chunk_size], hidden)
                if offset + logits.shape[1] > answer_start:
                    answer.append(logits[:, max(0, answer_start-offset):])
        # Keep the entire answer even if it straddles a chunk boundary.
        counts = score(torch.cat(answer, dim=1).float(), labels, memory)
        totals = [a+b for a,b in zip(totals,counts)]
    return dict(memory_len=memory, T=horizon, prefix=prefix, n=samples,
                token_correct=totals[0], string_correct=totals[1],
                token_acc=totals[0]/totals[2], string_acc=totals[1]/totals[3])


def atomic_json(path, data):
    path = Path(path)
    temp = path.with_suffix(path.suffix+".tmp")
    temp.write_text(json.dumps(data, indent=2)+"\n")
    temp.replace(path)
