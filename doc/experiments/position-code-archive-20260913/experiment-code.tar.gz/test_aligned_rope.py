"""Independent absolute-frame oracles for endpoint-aligned RoPE compression.

The references use complex arithmetic and retain absolute-frame keys or full
leaf coefficients. They never call the production rotations or compressor.
All tests are deliberately small and CPU-only.
"""

import copy
import math

import pytest
import torch
import torch.nn.functional as F

from configuration_logkv import LogKVConfig
from logkv import Compressor, LogKV
from logkv_lm import LogKVLM


def _rotate_reference(x, positions, scale=1.0):
    """Complex multiplication, calculated independently in double precision."""
    positions = torch.as_tensor(positions, device=x.device, dtype=torch.float64)
    frequencies = x.new_tensor(
        [10000.0 ** (-2 * r / x.shape[-1]) for r in range(x.shape[-1] // 2)],
        dtype=torch.float64,
    )
    angles = positions[..., None] * frequencies * scale
    z = torch.complex(x[..., 0::2].double(), x[..., 1::2].double())
    rotated = z * torch.polar(torch.ones_like(angles), angles)
    return torch.view_as_real(rotated).flatten(-2).to(x.dtype)


def _absolute_hierarchy(q, k, v, chunk_size, angle_scale):
    """Keep every block's key in one original, absolute coordinate frame."""
    length = q.shape[1]
    positions = torch.arange(length, device=q.device)
    levels = [(q, _rotate_reference(k, positions, angle_scale), v)]
    span = 1
    while levels[-1][0].shape[1] >= chunk_size:
        children_q, children_k, children_v = levels[-1]
        count = children_q.shape[1] // chunk_size
        end = count * chunk_size
        parent_q = children_q[:, chunk_size - 1:end:chunk_size]
        grouped_k = children_k[:, :end].reshape(q.shape[0], count, chunk_size, q.shape[-1])
        grouped_v = children_v[:, :end].reshape_as(grouped_k)
        span *= chunk_size
        endpoints = torch.arange(1, count + 1, device=q.device) * span - 1
        absolute_q = _rotate_reference(parent_q, endpoints, angle_scale)
        weights = ((absolute_q[:, :, None] * grouped_k).sum(-1)
                   / math.sqrt(q.shape[-1])).softmax(-1)
        levels.append((parent_q, (weights[..., None] * grouped_k).sum(-2),
                       (weights[..., None] * grouped_v).sum(-2)))
    return levels


def _absolute_attention(q, k, v, chunk_size, angle_scale, self_slot):
    levels = _absolute_hierarchy(q, k, v, chunk_size, angle_scale)
    absolute_queries = _rotate_reference(q, torch.arange(q.shape[1]), angle_scale)
    outputs = []
    for t in range(q.shape[1]):
        logits, values = [], []
        for level, (_, keys, vals) in enumerate(levels):
            unit = chunk_size ** level
            completed = (t // unit) % chunk_size
            first = (t // (unit * chunk_size)) * chunk_size
            for child in range(completed):
                logits.append((absolute_queries[:, t] * keys[:, first + child]).sum(-1)
                              / math.sqrt(q.shape[-1]) - level * math.log(chunk_size))
                values.append(vals[:, first + child])
        if self_slot:
            logits.append((q[:, t] * k[:, t]).sum(-1) / math.sqrt(q.shape[-1]))
            values.append(v[:, t])
        if logits:
            weights = torch.stack(logits, -1).softmax(-1)
            outputs.append((weights[..., None] * torch.stack(values, -2)).sum(-2))
        else:
            outputs.append(torch.zeros_like(q[:, t]))
    return torch.stack(outputs, 1), levels


@pytest.mark.parametrize("chunk_size", [2, 3, 4])
@pytest.mark.parametrize("self_slot", [False, True])
def test_aligned_attention_matches_absolute_oracle_and_gradients(chunk_size, self_slot):
    torch.manual_seed(120 + chunk_size)
    length = chunk_size ** 2 + chunk_size + 1
    actual_inputs = [torch.randn(4, length, 8, dtype=torch.float64, requires_grad=True)
                     for _ in range(3)]
    reference_inputs = [x.detach().clone().requires_grad_() for x in actual_inputs]
    model = LogKV(16, chunk_size, num_heads=2, self_slot=self_slot,
                  aligned_rope=True, aligned_rope_scale=2 / 3).double()
    actual, (state, offset) = model._attend(*actual_inputs, None)
    expected, hierarchy = _absolute_attention(*reference_inputs, chunk_size, 2 / 3, self_slot)
    torch.testing.assert_close(actual, expected, atol=3e-12, rtol=3e-12)
    assert offset == length
    for level, (stored_q, stored_k, stored_v) in enumerate(state):
        span = chunk_size ** level
        count = (length // span) % chunk_size
        assert stored_k.shape[1] == count
        if not count:
            continue
        first = length // span - count
        endpoints = (torch.arange(first, first + count) + 1) * span - 1
        ref_q, absolute_k, ref_v = hierarchy[level]
        torch.testing.assert_close(stored_q, ref_q[:, first:first + count], atol=0, rtol=0)
        torch.testing.assert_close(
            _rotate_reference(stored_k, endpoints, 2 / 3),
            absolute_k[:, first:first + count], atol=3e-12, rtol=3e-12,
        )
        torch.testing.assert_close(stored_v, ref_v[:, first:first + count], atol=3e-12, rtol=3e-12)
    loss_weights = torch.randn_like(actual)
    (actual * loss_weights).sum().backward()
    (expected * loss_weights).sum().backward()
    for actual_input, reference_input in zip(actual_inputs, reference_inputs):
        torch.testing.assert_close(actual_input.grad, reference_input.grad, atol=7e-12, rtol=7e-12)


@pytest.mark.parametrize("chunk_size", [2, 3, 4])
def test_recursive_pool_is_weighted_original_leaf_keys_in_parent_frame(chunk_size):
    """Catch rotating only logits, wrong span, wrong anchor, and rotated V."""
    torch.manual_seed(321)
    rows, dim, length = 6, 8, chunk_size ** 3
    leaf_q, leaf_k, leaf_v = [torch.randn(rows, length, dim, dtype=torch.float64)
                            for _ in range(3)]
    compressor = Compressor(num_heads=3, chunk_size=chunk_size, head_dim=dim,
                            aligned_rope=True, aligned_rope_scale=0.5).double()
    actual_q, actual_k, actual_v = leaf_q, leaf_k, leaf_v
    coefficients = torch.eye(length, dtype=torch.float64).expand(rows, length, length)
    absolute_leaf_keys = _rotate_reference(leaf_k, torch.arange(length), 0.5)
    absolute_keys = absolute_leaf_keys
    span = 1
    for _ in range(3):
        count = actual_q.shape[1] // chunk_size
        shape = (rows * count, chunk_size, dim)
        next_q, next_k, next_v = compressor(
            actual_q.reshape(shape), actual_k.reshape(shape), actual_v.reshape(shape),
            num_chunks=count, child_span=span,
        )
        next_q, next_k, next_v = [x.reshape(rows, count, dim) for x in (next_q, next_k, next_v)]
        endpoints = torch.arange(1, count + 1) * span * chunk_size - 1
        absolute_query = _rotate_reference(leaf_q[:, endpoints], endpoints, 0.5)
        children = absolute_keys.reshape(rows, count, chunk_size, dim)
        weights = ((absolute_query[:, :, None] * children).sum(-1) / math.sqrt(dim)).softmax(-1)
        coefficients = (weights[..., None]
                        * coefficients.reshape(rows, count, chunk_size, length)).sum(-2)
        relative_leaf_positions = torch.arange(length)[None] - endpoints[:, None]
        leaf_keys_in_parent_frame = _rotate_reference(
            leaf_k[:, None], relative_leaf_positions, 0.5,
        )
        expected_k = (coefficients[..., None] * leaf_keys_in_parent_frame).sum(-2)
        expected_v = torch.einsum("bnl,bld->bnd", coefficients, leaf_v)
        torch.testing.assert_close(next_q, leaf_q[:, endpoints], atol=0, rtol=0)
        torch.testing.assert_close(next_k, expected_k, atol=3e-12, rtol=3e-12)
        torch.testing.assert_close(next_v, expected_v, atol=3e-12, rtol=3e-12)
        absolute_keys = torch.einsum("bnl,bld->bnd", coefficients, absolute_leaf_keys)
        actual_q, actual_k, actual_v = next_q, next_k, next_v
        span *= chunk_size


@pytest.mark.parametrize("checkpoint_attention", [False, True])
def test_projected_multihead_output_and_parameter_gradients(checkpoint_attention):
    torch.manual_seed(72)
    model = LogKV(16, 3, num_heads=2, aligned_rope=True,
                  self_slot=True, gated_attention=True).double()
    model.recompute_attention = checkpoint_attention
    reference = copy.deepcopy(model)
    x = torch.randn(2, 31, 16, dtype=torch.float64, requires_grad=True)
    ref_x = x.detach().clone().requires_grad_()

    def fold(tensor):
        return tensor.reshape(2, 31, 2, 8).permute(0, 2, 1, 3).reshape(4, 31, 8)

    q, k, v = [fold(F.linear(ref_x, layer.weight))
               for layer in (reference.lq, reference.lk, reference.lv)]
    attended, _ = _absolute_attention(q, k, v, 3, 1.0, True)
    attended = attended * fold(F.linear(ref_x, reference.lg.weight, reference.lg.bias)).sigmoid()
    merged = attended.reshape(2, 2, 31, 8).permute(0, 2, 1, 3).reshape(2, 31, 16)
    expected = F.linear(merged, reference.lo.weight)
    actual = model(x)
    torch.testing.assert_close(actual, expected, atol=3e-12, rtol=3e-12)
    loss_weights = torch.randn_like(actual)
    (actual * loss_weights).sum().backward()
    (expected * loss_weights).sum().backward()
    torch.testing.assert_close(x.grad, ref_x.grad, atol=7e-12, rtol=7e-12)
    for (name, param), (ref_name, ref_param) in zip(model.named_parameters(), reference.named_parameters()):
        assert name == ref_name
        assert param.grad is not None, name
        torch.testing.assert_close(param.grad, ref_param.grad, atol=1e-11, rtol=1e-11, msg=name)


@pytest.mark.parametrize("chunk_size", [2, 3, 4])
@pytest.mark.parametrize("self_slot", [False, True])
def test_aligned_streaming_carry_boundaries_causality_and_immutable_cache(chunk_size, self_slot):
    torch.manual_seed(53)
    model = LogKV(16, chunk_size, num_heads=2, self_slot=self_slot,
                  aligned_rope=True, gated_attention=True).double().eval()
    length = chunk_size ** 3 + 3
    x = torch.randn(2, length, 16, dtype=torch.float64)
    cuts = sorted({0, 1, chunk_size - 1, chunk_size, chunk_size + 1,
                   chunk_size ** 2 - 1, chunk_size ** 2, chunk_size ** 2 + 1,
                   chunk_size ** 3 - 1, chunk_size ** 3, chunk_size ** 3 + 1, length})
    with torch.no_grad():
        full = model(x)
        hidden, outputs = None, []
        for begin, end in zip(cuts, cuts[1:]):
            snapshot = copy.deepcopy(hidden)
            if end == begin + 1:
                out, next_hidden = model.predict(x[:, begin], hidden)
                out = out[:, None]
            else:
                out, next_hidden = model.step(x[:, begin:end], hidden)
            if hidden is not None:
                assert hidden[1] == snapshot[1]
                for old_level, saved_level in zip(hidden[0], snapshot[0]):
                    for old_tensor, saved_tensor in zip(old_level, saved_level):
                        assert torch.equal(old_tensor, saved_tensor)
            hidden = next_hidden
            outputs.append(out)
            for level, tensors in enumerate(hidden[0]):
                assert all(t.shape[1] == (end // chunk_size ** level) % chunk_size for t in tensors)
        torch.testing.assert_close(torch.cat(outputs, 1), full, atol=3e-12, rtol=3e-12)
        changed = x.clone()
        boundary = chunk_size ** 2
        changed[:, boundary:] += torch.randn_like(changed[:, boundary:]) * 20
        torch.testing.assert_close(model(changed)[:, :boundary], full[:, :boundary], atol=0, rtol=0)


@pytest.mark.parametrize("dtype", [torch.float32, torch.bfloat16, torch.float64])
def test_aligned_rotation_preserves_large_integer_position_differences(dtype):
    from logkv import _aligned_rope

    positions = torch.tensor([-(2 ** 24 + 1), -(2 ** 24), -(2 ** 24 - 1), -(2 ** 32 + 1)])
    x = torch.tensor([[1., 0., 0.5, -0.25]]).expand(4, 4).to(dtype)
    actual = _aligned_rope(x, positions, scale=1.0)
    expected = _rotate_reference(x, positions)
    assert actual.dtype == dtype
    assert not torch.equal(actual[0], actual[1])
    torch.testing.assert_close(actual, expected, atol=2e-7 if dtype == torch.float32 else 1e-12,
                               rtol=2e-7 if dtype == torch.float32 else 1e-12)


def test_large_offset_retrieval_uses_integer_endpoint_minus_query():
    """Exercise distant coarse slots without allocating a 134M-token prefix."""
    torch.manual_seed(14)
    chunk_size, offset, rows, dim = 4, 2 * 4 ** 13 + 3, 2, 4
    model = LogKV(8, chunk_size, num_heads=2, self_slot=True, aligned_rope=True).double()
    levels = []
    logits, values = [], []
    q, k, v = [torch.randn(rows, 1, dim, dtype=torch.float64) for _ in range(3)]
    for level in range(14):
        span = chunk_size ** level
        count = (offset // span) % chunk_size
        tensors = [torch.randn(rows, count, dim, dtype=torch.float64) for _ in range(3)]
        levels.append(tensors)
        for child in range(count):
            endpoint = (offset // span - count + child + 1) * span - 1
            rotated = _rotate_reference(tensors[1][:, child], endpoint - offset)
            logits.append((q[:, 0] * rotated).sum(-1) / math.sqrt(dim) - level * math.log(chunk_size))
            values.append(tensors[2][:, child])
    logits.append((q[:, 0] * k[:, 0]).sum(-1) / math.sqrt(dim))
    values.append(v[:, 0])
    expected = (torch.stack(logits, -1).softmax(-1)[..., None] * torch.stack(values, -2)).sum(-2)
    actual, updated = model._attend(q, k, v, (levels, offset))
    torch.testing.assert_close(actual[:, 0], expected, atol=3e-12, rtol=3e-12)
    assert updated[1] == offset + 1


@pytest.mark.parametrize("self_slot", [False, True])
def test_aligned_lm_config_save_load_and_streaming(tmp_path, self_slot):
    cfg = LogKVConfig(vocab_size=12, d_model=16, num_heads=2, d_ff=32, num_layers=2,
                      chunk_size=3, aligned_rope=True, aligned_rope_scale=0.5,
                      gated_attention=True, self_slot=self_slot,
                      pad_token_id=None, bos_token_id=None, eos_token_id=None)
    model = LogKVLM(cfg).double().eval()
    ids = torch.randint(0, 12, (2, 32))
    with torch.no_grad():
        expected = model(ids).logits
        head, hidden = model.step(ids[:, :26])
        pieces = [head]
        for t in range(26, 32):
            logits, hidden = model.predict(ids[:, t], hidden)
            pieces.append(logits[:, None])
        torch.testing.assert_close(torch.cat(pieces, 1), expected, atol=3e-12, rtol=3e-12)
    model.save_pretrained(tmp_path)
    loaded = LogKVLM.from_pretrained(tmp_path).double().eval()
    assert loaded.config.aligned_rope
    assert loaded.config.aligned_rope_scale == 0.5
    for layer in loaded.layers:
        assert layer.attention.aligned_rope and layer.attention.compressor.aligned_rope
        assert layer.attention.aligned_rope_scale == 0.5
        assert layer.attention.compressor.aligned_rope_scale == 0.5
    with torch.no_grad():
        torch.testing.assert_close(loaded(ids).logits, expected, atol=0, rtol=0)
        low_precision = loaded.to(torch.bfloat16)(ids).logits
        assert low_precision.dtype == torch.bfloat16 and torch.isfinite(low_precision).all()
        torch.testing.assert_close(low_precision.float(), expected.float(), atol=0.15, rtol=0.05)


def test_disabled_mode_preserves_parameters_rng_outputs_and_gradients():
    options = dict(dim=16, chunk_size=4, num_heads=2, self_slot=True, retrieval_rope=True)
    torch.manual_seed(198)
    old_default = LogKV(**options).double()
    old_rng = torch.get_rng_state()
    torch.manual_seed(198)
    explicit_disabled = LogKV(**options, aligned_rope=False, aligned_rope_scale=0.5).double()
    assert torch.equal(old_rng, torch.get_rng_state())
    for key, value in old_default.state_dict().items():
        assert torch.equal(value, explicit_disabled.state_dict()[key])
    x = torch.randn(2, 23, 16, dtype=torch.float64, requires_grad=True)
    ref_x = x.detach().clone().requires_grad_()
    actual, expected = explicit_disabled(x), old_default(ref_x)
    assert torch.equal(actual, expected)
    actual.square().sum().backward()
    expected.square().sum().backward()
    assert torch.equal(x.grad, ref_x.grad)
    for actual_param, expected_param in zip(explicit_disabled.parameters(), old_default.parameters()):
        assert torch.equal(actual_param.grad, expected_param.grad)
    old_config = LogKVConfig.from_dict({"d_model": 16, "num_heads": 2})
    assert old_config.aligned_rope is False and old_config.aligned_rope_scale == 1.0


@pytest.mark.parametrize("conflict", ["retrieval_rope", "compressor_rope", "relative_position_kv",
                                      "compressor_position_transform", "kv_norm"])
def test_aligned_incompatible_key_frames_are_rejected(conflict):
    with pytest.raises(ValueError):
        LogKV(16, 4, num_heads=2, aligned_rope=True, **{conflict: True})


@pytest.mark.parametrize("scale", [0.0, -1.0, float("inf"), float("nan")])
def test_aligned_scale_validation(scale):
    with pytest.raises(ValueError):
        LogKV(16, 4, num_heads=2, aligned_rope=True, aligned_rope_scale=scale)
    with pytest.raises(ValueError):
        Compressor(head_dim=8, aligned_rope=True, aligned_rope_scale=scale)


def test_aligned_odd_head_dimension_is_rejected():
    with pytest.raises(ValueError):
        LogKV(14, 4, num_heads=2, aligned_rope=True)
    with pytest.raises(ValueError):
        Compressor(head_dim=7, aligned_rope=True)
